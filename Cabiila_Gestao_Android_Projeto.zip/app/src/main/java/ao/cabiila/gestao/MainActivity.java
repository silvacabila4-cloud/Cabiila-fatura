package ao.cabiila.gestao;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.MediaStore;import android.webkit.*;import android.util.Base64;import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.*;
public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);web.setWebViewClient(new WebViewClient());web.addJavascriptInterface(new Bridge(),"AndroidBridge");web.loadUrl("file:///android_asset/index.html");}
 class Bridge {
  private byte[] decode(String s){return Base64.decode(s,Base64.DEFAULT);}
  private String safe(String s){return s.replaceAll("[^a-zA-Z0-9._-]","_");}
  @JavascriptInterface public void sharePdf(String b64,String name,String message){try{File dir=new File(getCacheDir(),"pdfs");dir.mkdirs();File f=new File(dir,safe(name));try(FileOutputStream out=new FileOutputStream(f)){out.write(decode(b64));}Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",f);Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/pdf");send.putExtra(Intent.EXTRA_STREAM,uri);send.putExtra(Intent.EXTRA_TEXT,message);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);runOnUiThread(()->startActivity(Intent.createChooser(send,"Partilhar fatura PDF")));}catch(Exception ex){notifyError(ex);}}
  @JavascriptInterface public void savePdf(String b64,String name){try{ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,safe(name));v.put(MediaStore.Downloads.MIME_TYPE,"application/pdf");v.put(MediaStore.Downloads.RELATIVE_PATH,"Download/CabiilaGestao");Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new IOException("Falha ao criar PDF");try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(decode(b64));}runOnUiThread(()->Toast.makeText(MainActivity.this,"PDF guardado em Downloads/CabiilaGestao",Toast.LENGTH_LONG).show());}catch(Exception ex){notifyError(ex);}}
  private void notifyError(Exception ex){runOnUiThread(()->Toast.makeText(MainActivity.this,"Erro no PDF: "+ex.getMessage(),Toast.LENGTH_LONG).show());}
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
